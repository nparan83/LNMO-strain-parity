#!/bin/bash
#SBATCH -J Fix_-0.05
#SBATCH -p hamsi
#SBATCH -A nparan
#SBATCH -N 1
#SBATCH -n 56
#SBATCH --time=01:00:00

module purge
module load comp/oneapi/2023
module load lib/hdf5/1.14.3-oneapi-2023.0
module load apps/espresso/7.2-oneapi-2023.0

mpirun dos.x < dos_FM.in > dos_FM.out
mpirun projwfc.x < pdos_FM.in > pdos_FM.out
